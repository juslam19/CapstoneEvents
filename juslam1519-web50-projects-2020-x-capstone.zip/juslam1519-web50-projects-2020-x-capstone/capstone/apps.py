from django.apps import AppConfig


class CapstoneConfig(AppConfig):
    name = 'capstone'
